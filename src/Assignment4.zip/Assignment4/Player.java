package Assignment4;

import java.util.LinkedList;

/**
 * Player class
 * Assignment 4
 * CP2561 Winter 2022
 * @author Quynh
 */
public class Player {
    private String name;
    private LinkedList<Card> hand;

    /**
     * Constructor creates a player object with a name and a hand
     * @param name (string) player first name
     * @param hand (linkedlist) represents card objects assigned to the player
     */
    public Player(String name, LinkedList<Card> hand) {
        this.name = name;
        this.hand = hand;
    }

    /**
     * Get first name of player
     * @return first name of player
     */
    public String getName() {
        return name;
    }

    /**
     * Set first name of player
     * @param name first name to set to player
     */
    public void setName(String name) {
        this.name = name;
    }

    public LinkedList<Card> getHand() {
        return hand;
    }

    public void setHand(LinkedList<Card> hand) {
        this.hand = hand;
    }


    public void printHand(){
        for (Card card :this.hand) {
            System.out.println(card);
        }
    }
    public void printFirstCardOfHand(int currentGame){
        System.out.println(this.hand.get(currentGame-1));
    }
}
