package Assignment4;

import java.util.*;

/**
 * OneHundreds class
 * Assignment 4
 * CP2561 Winter 2022
 * @author Quynh
 */
public class OneHundreds {
    public static void main(String[] args) {
        System.out.println("How many players (2-4): ");
        Scanner sc = new Scanner(System.in);
        int numberOfPlayers = sc.nextInt();

        List<Player> playerList = new ArrayList<>();
        Map<String, Integer> scoreMap = new HashMap<>();

        for (int i = 0; i < numberOfPlayers ; i++) {
            System.out.println("Enter player name: ");
            String name = sc.next();
            Player player = new Player(name,new LinkedList<Card>());
            playerList.add(player);
            scoreMap.put(name, 0);
        }
        CardDeck cardDeck = new CardDeck();
        ArrayList<Card> deck = cardDeck.generateDeck();
        cardDeck.shuffleDeck(deck);
        dealCard(deck, playerList, scoreMap);

    }

    public static void dealCard(ArrayList<Card> deck, List<Player> playerList, Map<String, Integer> scoreMap){
        int currentGame = 1;
        while (deck.size() >= playerList.size()){
            for (int i = 0; i < playerList.size(); i++) {
                playerList.get(i).getHand().add(deck.get(0));
                deck.remove(0);
            }
            for (int i = 0; i < playerList.size(); i++) {
                playerList.get(i).printFirstCardOfHand(currentGame);
            }
            Player winnerPlayer = winnerPlayer(currentGame, playerList);
            System.out.println(winnerPlayer.getName());
            Integer winnerScore = scoreMap.get(winnerPlayer.getName());
            winnerScore = winnerScore + 1;
            scoreMap.put(winnerPlayer.getName(), winnerScore);
            System.out.println(scoreMap);
            currentGame++;
        }
    }

    public static Player winnerPlayer(int currentGame, List<Player> playerList){
        Player winnerPlayer = playerList.get(0);
        Card winnerCard = winnerPlayer.getHand().get(currentGame - 1);
        for (int i = 1; i < playerList.size(); i++) {
            Card playerCard = playerList.get(i).getHand().get(currentGame - 1);
            if(!winnerCard.compareTo(playerCard))
                winnerPlayer = playerList.get(i);
        }

        return winnerPlayer;
    }
}
